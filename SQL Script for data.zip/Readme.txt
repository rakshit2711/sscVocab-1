create database sscvocab.
then run the sql script given in the folder
It contains both (Tables with data and Tables without Data only run scripts from one folder)
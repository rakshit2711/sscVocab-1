-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: sscvocab
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vocab`
--

DROP TABLE IF EXISTS `vocab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vocab` (
  `id` int NOT NULL AUTO_INCREMENT,
  `word` varchar(255) DEFAULT NULL,
  `meaning` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocab`
--
-- ORDER BY:  `id`

LOCK TABLES `vocab` WRITE;
/*!40000 ALTER TABLE `vocab` DISABLE KEYS */;
INSERT INTO `vocab` VALUES (1,'Rueful','Sad and Regretful'),(2,'Linguistic','A student of Linguistics / One who can speak many Languages'),(3,'Lingua Franca','a language that is adopted as a common language between speakers whose native languages are different'),(4,'Chronology','Study of event in the order of their occurrence'),(5,'Chronic','Lasting for a long time(generally for a disease)'),(6,'Chronicle','Written record of historical event describing them in order of their time'),(7,'Synchronous','Existing or occurring at the same time'),(8,'Asynchronous','Not existing or occurring at the same time'),(9,'Chronometer','Instrument that measures time'),(10,'Polyglot','One who can speak many languages / (of a book) having the text translated into several languages.'),(11,'Polygamy','Practice of many marriage'),(12,'Polyandry','Practice of many husband'),(13,'Polygyny','Practice of keeping many wives'),(14,'Polyarchy','Ruled by many'),(15,'Polymorphic','Having many forms'),(16,'Polydemic','Affecting many people'),(17,'Bilingual','One who knows two languages / of two languages'),(18,'Disparage','To belittle someone\'s effort / degrade'),(19,'Verbatim','Written or told in exactly same way'),(20,'Amicus curiae','One who aids and assist the court'),(21,'Amity','friendly relations'),(22,'Amiable','having or displaying a friendly and pleasant manner'),(23,'Amicable','Friendly / Cooperative'),(24,'Amicide','Killing one\'s friend'),(25,'Inimical','tending to obstruct or harm / unfriendly ,  hostile'),(26,'Vagrant','Homeless and Jobless person  who lives by begging'),(27,'Impudence','Rude Behavior'),(28,'Seemly','Good looking , Handsome'),(29,'Comely','Pretty or Attractive'),(30,'Sightly','Pleasing to eye , Attractive'),(31,'Goodly','Pleasant , Attractive / considerable in size or quantity'),(32,'Homely','Not pretty or handsome / simple but cozy and comfortable, as in one\'s own home'),(33,'Glutton','A person who eats too much'),(34,'Gourmand','A person who enjoys eating and often eats too much'),(35,'Gourmet','A person who appreciate fine food and drink'),(36,'Gastronomy','the practice or art of choosing, cooking, and eating good food'),(37,'Sitophobic','who have fear of food'),(38,'Vainglory','Excessive pride in oneself or one\'s achievements , excessive vanity'),(39,'Vanity','Inflated pride in oneself'),(40,'Beeline','A straight direct course'),(41,'Pedantic','Excessively concerned with minor details or rule'),(42,'Sojourn','A temporary stay'),(43,'Fortitude','Strength of mind that lets a person meet danger , pain or hardship with courage'),(44,'Exodus','A mass departure of people'),(45,'Migrant','A person who goes from one place to another specially to find work'),(46,'Emigrant','One who leave one\'s country or region to live in another'),(47,'Immigrant','Person who comes to your country and take up residence'),(48,'Itinerant','Travelling from place to place'),(49,'Dumb Founded','To be speechless with surprise'),(50,'Aghast','Filled with horror or shock'),(51,'Flabbergast','Surprise (someone) greatly; astonish'),(52,'Astonish','Surprise or impress (someone) greatly.'),(53,'Flimsy','Insubstantial and easily damaged / very light and thin / weak and unconvincing'),(54,'Sky Rocket','Increase Rapidly'),(55,'Prejudice','Preconceived opinion that is not based on reason or actual experience'),(56,'Laud','Praise Highly'),(57,'Admonish','To chide or scold / advise or urge (someone) earnestly / warn (someone) of something to be avoided'),(58,'Rebuff','An abrupt or ungracious rejection of an offer, request, or friendly gesture /  Reject (someone or something) in an abrupt or ungracious manner'),(59,'Rebuke','An expression of sharp disapproval or criticism'),(60,'Chastise','Rebuke or reprimand severely'),(61,'Reprimand','A formal expression of disapproval.'),(62,'Chide','Scold or rebuke'),(63,'Pompous','Affectedly grand, solemn, or self-important / Showy'),(64,'Ostentatious','Characterized by pretentious or showy display; designed to impress'),(65,'Autopsy','A post-mortem examination to discover the cause of death or the extent of disease'),(66,'Biopsy','An examination of tissue removed from a living body to discover the presence, cause, or extent of a disease'),(67,'Facsimile','An exact copy, especially of written or printed material / Make a copy of'),(68,'Sporadic','Not happening regularly / scattered or isolated'),(69,'Idiosyncrasy','A mode of behavior or way of thought peculiar to an individual'),(70,'Peculiar','Different to what is normal or expected; strange'),(71,'Abysymal','Very bad , of poor quality /  very deep'),(72,'Abyss','A deep or seemingly bottomless chasm / he regions of hell conceived of as a bottomless pit'),(73,'Abridge','Shorten (a piece of writing) without losing the sense'),(74,'Lack Lusture','Not interesting or exciting , dull'),(75,'Epitome','A perfect Example / a summary of a written work , an abstract'),(76,'Abstract','Existing in thought or as an idea but not having a physical or concrete existence'),(77,'Jocular','Humorous / Fond of or characterized by joking'),(78,'Humorous','Causing laughter and amusement'),(79,'Humour','The quality of being amusing or comic'),(80,'Impasse','A difficult situation in which no progress can be made due to disagreement'),(81,'Zenith','Highest point'),(82,'Nadir','Lowest point / The worst moment of a sudden'),(83,'Tall Talk','Exaggerate'),(84,'Pep Talk','Speech that is given to encourage People');
/*!40000 ALTER TABLE `vocab` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-17  0:34:51
